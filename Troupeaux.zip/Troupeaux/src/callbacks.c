

#ifdef HAVE_CONFIG_H
#  include <config.h>
#endif

#include <gtk/gtk.h>

#include <stdio.h>
#include <string.h>
#include <stdlib.h>

#include "callbacks.h"
#include "interface.h"
#include "support.h"
#include "animal.h"


int y=1;
int z=1;
int choix2[]={0,0,0};
int choix3[]={0,0,0};


void
on_buttonCalculer_GTA_clicked          (GtkWidget       *objet,
                                        gpointer         user_data)
{
GtkWidget *affichage, *output1, *output2, *output3, *output4;
int v,m,c,p;

v=nb_vache();
m=nb_mouton();
c=nb_cheval();
p=nb_poule();

char Vache[100];
char Mouton[100];
char Cheval[100];
char Poulet[100];

sprintf(Vache, "%d", v);
sprintf(Mouton, "%d", m);
sprintf(Cheval, "%d", c);
sprintf(Poulet, "%d", p);

output1 = lookup_widget(objet,"labelNbV");
gtk_label_set_text(GTK_LABEL(output1),Vache);

output2 = lookup_widget(objet,"labelNbM");
gtk_label_set_text(GTK_LABEL(output2),Mouton);

output3 = lookup_widget(objet,"labelNbC");
gtk_label_set_text(GTK_LABEL(output3),Cheval);

output4 = lookup_widget(objet,"labelNbP");
gtk_label_set_text(GTK_LABEL(output4),Poulet);
}
            

void
on_buttonCalculer_AS_clicked           (GtkWidget       *objet,
                                        gpointer         user_data)
{
GtkWidget *affichage, *output5;
int as;

as=annee_seche();

char seche[100];

sprintf(seche, "%d", as);

output5 = lookup_widget(objet,"labelAS2");
gtk_label_set_text(GTK_LABEL(output5),seche);
}


void
on_treeviewGT1_row_activated           (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data)
{
GtkTreeIter Iter;
gchar *Id;
gchar *Famille;
gchar *Sexe;
gchar *Poids;
gchar *Sante;
gchar *Date;
animal a;
GtkTreeModel *model = gtk_tree_view_get_model(treeview);

if(gtk_tree_model_get_iter(model,&Iter,path))
{
gtk_tree_model_get(GTK_LIST_STORE(model),&Iter,0,&Id,1,&Famille,2,&Sexe,3,&Poids,4,&Sante,5,&Date,-1);

strcpy(a.id,Id);

supp_animal(a.id);
}

}


void
on_buttonAjouter_GT1_clicked           (GtkWidget       *objet,
                                        gpointer         user_data)
{
GtkWidget *window1;
GtkWidget *window2;
window1 = lookup_widget(objet,"GT_Employe1");
window2 = create_GT_Employe2 ();
gtk_widget_destroy(window1);
gtk_widget_show(window2);
}


void
on_buttonModifier_GT1_clicked          (GtkWidget       *objet,
                                        gpointer         user_data)
{
GtkWidget *window1;
GtkWidget *window2;
window1 = lookup_widget(objet,"GT_Employe1");
window2 = create_GT_Employe3 ();
gtk_widget_destroy(window1);
gtk_widget_show(window2);
}


void
on_buttonSupp_GT1_clicked              (GtkWidget       *objet,
                                        gpointer         user_data)
{
GtkWidget *input;
char ident[50];

input=lookup_widget(objet,"entrySupp_GT1");
strcpy(ident,gtk_entry_get_text(GTK_ENTRY(input)));

supp_animal(ident);
}


void
on_buttonMAJ_clicked                   (GtkWidget       *objet,
                                        gpointer         user_data)
{
GtkWidget *window;
GtkWidget *treeview;
window   = lookup_widget(objet,"GT_Employe1");
treeview = lookup_widget(window,"treeviewGT1");

afficher_animal(treeview);
}


void
on_buttonConfirmer_GT2_clicked         (GtkWidget       *objet,
                                        gpointer         user_data)
{
animal a;

GtkWidget *input1;
GtkWidget *input2;
GtkWidget *spin1;
GtkWidget *spin2;
GtkWidget *spin3;
GtkWidget *comboboxentry2;

input1 = lookup_widget(objet,"entryId_GT2");
comboboxentry2 = lookup_widget(objet,"comboboxentryFam_GT2");
input2=lookup_widget(objet,"entryPoids_GT2");
spin1 = lookup_widget(objet,"spinbuttonJ_GT2");
spin2 = lookup_widget(objet,"spinbuttonM_GT2");
spin3 = lookup_widget(objet,"spinbuttonA_GT2");


strcpy(a.id,gtk_entry_get_text(GTK_ENTRY(input1)));
strcpy(a.famille,gtk_combo_box_get_active_text(GTK_COMBO_BOX(comboboxentry2)));
if (y == 1)
{
	strcpy(a.sexe,"Male");
}
if (y == 2)
{
	strcpy(a.sexe,"Femelle");
}
strcpy(a.poids,gtk_entry_get_text(GTK_ENTRY(input2)));
if (choix2[0]==1)
{
	strcpy(a.sante.vac,"Vac");
}
if (choix2[0]==0)
{
	strcpy(a.sante.vac,"Non_Vac");
}
if (choix2[1]==1)
{
	strcpy(a.sante.malade,"Mal");
}
if (choix2[1]==0)
{
	strcpy(a.sante.malade,"Non_Mal");
}
if (choix2[2]==1)
{
	strcpy(a.sante.gestante,"Ges");
}
if (choix2[2]==0)
{
	strcpy(a.sante.gestante,"Non_Ges");
}
a.date.j = gtk_spin_button_get_value_as_int (GTK_SPIN_BUTTON (spin1));
a.date.m = gtk_spin_button_get_value_as_int (GTK_SPIN_BUTTON (spin2));
a.date.a = gtk_spin_button_get_value_as_int (GTK_SPIN_BUTTON (spin3));

ajouter_animal(a);
}


void
on_buttonAfficher_GT2_clicked          (GtkWidget       *objet,
                                        gpointer         user_data)
{
GtkWidget *window1;
GtkWidget *window2;
window1 = lookup_widget(objet,"GT_Employe2");
window2 = create_GT_Employe1 ();
gtk_widget_destroy(window1);
gtk_widget_show(window2);
}


void
on_radiobuttonM_GT2_toggled            (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if (gtk_toggle_button_get_active(GTK_RADIO_BUTTON(togglebutton)))
{y=1;}
}


void
on_radiobuttonF_GT2_toggled            (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if (gtk_toggle_button_get_active(GTK_RADIO_BUTTON(togglebutton)))
{y=2;}
}


void
on_checkbuttonVac_GT2_toggled          (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if (gtk_toggle_button_get_active(togglebutton))
{choix2[0]=1;}
}


void
on_checkbuttonMal_GT2_toggled          (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if (gtk_toggle_button_get_active(togglebutton))
{choix2[1]=1;}
}


void
on_checkbuttonGes_GT2_toggled          (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if (gtk_toggle_button_get_active(togglebutton))
{choix2[2]=1;}
}


void
on_buttonRech_GT3_clicked              (GtkWidget       *objet,
                                        gpointer         user_data)
{
animal a;
int r;
char texte[100];
char texte2[100];
GtkWidget *input1;
GtkWidget *input2;
GtkWidget *input3;
GtkWidget *spin1;
GtkWidget *spin2;
GtkWidget *spin3;
GtkWidget *comboboxentry3;
GtkWidget *status;

input3 = lookup_widget(objet,"entryRech_GT3");
input1 = lookup_widget(objet,"entryId_GT3");
comboboxentry3 = lookup_widget(objet,"comboboxentryFam_GT3");
input2 = lookup_widget(objet,"entryPoids_GT3");
spin1 = lookup_widget(objet,"spinbuttonJ_GT3");
spin2 = lookup_widget(objet,"spinbuttonM_GT3");
spin3 = lookup_widget(objet,"spinbuttonA_GT3");
status = lookup_widget(objet,"labelFind_GT3");

strcpy(texte,gtk_entry_get_text(GTK_ENTRY(input3)));
r= rechercher_animal(texte);
if (r==0)
{
	strcpy(texte2,"Id non trouvé");
	gtk_label_set_text(GTK_LABEL(status),texte2);
} 
else 
{
	strcpy(texte2,"Id trouvé");
	gtk_label_set_text(GTK_LABEL(status),texte2);

	strcpy(a.id,find_animal(texte).id);
	strcpy(a.famille,find_animal(texte).famille);
	strcpy(a.poids,find_animal(texte).poids);
	strcpy(a.sexe,find_animal(texte).sexe);
	a.date.j = find_animal(texte).date.j;
	a.date.m = find_animal(texte).date.m;
	a.date.a = find_animal(texte).date.a;

	gtk_entry_set_text(GTK_ENTRY(input1),a.id);
	gtk_entry_set_text(GTK_ENTRY(input2),a.poids);
	if (z == 1)
	{
		strcpy(a.sexe,"Male");
	}
	if (z == 2)
	{
		strcpy(a.sexe,"Femelle");
	}
	if (choix3[0]==1)
	{
		strcpy(a.sante.vac,"Vac");
	}
	if (choix3[0]==0)
	{
		strcpy(a.sante.vac,"Non_Vac");
	}
	if (choix3[1]==1)
	{
		strcpy(a.sante.malade,"Mal");
	}
	if (choix3[1]==0)
	{
		strcpy(a.sante.malade,"Non_Mal");
	}
	if (choix3[2]==1)
	{
		strcpy(a.sante.gestante,"Ges");
	}
	if (choix3[2]==0)
	{
		strcpy(a.sante.gestante,"Non_Ges");
	}
	gtk_spin_button_set_value(GTK_SPIN_BUTTON (spin1),a.date.j);
        gtk_spin_button_set_value(GTK_SPIN_BUTTON (spin2),a.date.m);
	gtk_spin_button_set_value(GTK_SPIN_BUTTON (spin3),a.date.a);	
}
}

void
on_buttonConfirmer_GT3_clicked         (GtkWidget       *objet,
                                        gpointer         user_data)
{
animal a;

GtkWidget *input1;
GtkWidget *input2;
GtkWidget *spin1;
GtkWidget *spin2;
GtkWidget *spin3;
GtkWidget *comboboxentry3;

input1 = lookup_widget(objet,"entryId_GT3");
comboboxentry3 = lookup_widget(objet,"comboboxentryFam_GT3");
input2=lookup_widget(objet,"entryPoids_GT3");
spin1 = lookup_widget(objet,"spinbuttonJ_GT3");
spin2 = lookup_widget(objet,"spinbuttonM_GT3");
spin3 = lookup_widget(objet,"spinbuttonA_GT3");


strcpy(a.id,gtk_entry_get_text(GTK_ENTRY(input1)));
strcpy(a.famille,gtk_combo_box_get_active_text(GTK_COMBO_BOX(comboboxentry3)));
if (z == 1)
{
	strcpy(a.sexe,"Male");
}
if (z == 2)
{
	strcpy(a.sexe,"Femelle");
}
strcpy(a.poids,gtk_entry_get_text(GTK_ENTRY(input2)));
if (choix3[0]==1)
{
	strcpy(a.sante.vac,"Vac");
}
if (choix3[0]==0)
{
	strcpy(a.sante.vac,"Non_Vac");
}
if (choix3[1]==1)
{
	strcpy(a.sante.malade,"Mal");
}
if (choix3[1]==0)
{
	strcpy(a.sante.malade,"Non_Mal");
}
if (choix3[2]==1)
{
	strcpy(a.sante.gestante,"Ges");
}
if (choix3[2]==0)
{
	strcpy(a.sante.gestante,"Non_Ges");
}
a.date.j = gtk_spin_button_get_value_as_int (GTK_SPIN_BUTTON (spin1));
a.date.m = gtk_spin_button_get_value_as_int (GTK_SPIN_BUTTON (spin2));
a.date.a = gtk_spin_button_get_value_as_int (GTK_SPIN_BUTTON (spin3));

modif_animal(a);
}


void
on_buttonAfficher_GT3_clicked          (GtkWidget       *objet,
                                        gpointer         user_data)
{
GtkWidget *window1;
GtkWidget *window2;
window1 = lookup_widget(objet,"GT_Employe3");
window2 = create_GT_Employe1 ();
gtk_widget_destroy(window1);
gtk_widget_show(window2);
}


void
on_radiobuttonM_GT3_toggled            (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if (gtk_toggle_button_get_active(GTK_RADIO_BUTTON(togglebutton)))
{z=1;}
}


void
on_radiobuttonF_GT3_toggled            (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if (gtk_toggle_button_get_active(GTK_RADIO_BUTTON(togglebutton)))
{z=2;}
}


void
on_checkbuttonVac_GT3_toggled          (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if (gtk_toggle_button_get_active(togglebutton))
{choix3[0]=1;}
}


void
on_checkbuttonMal_GT3_toggled          (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if (gtk_toggle_button_get_active(togglebutton))
{choix3[1]=1;}
}


void
on_checkbuttonGes_GT3_toggled          (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if (gtk_toggle_button_get_active(togglebutton))
{choix3[2]=1;}
}

/////////////////////////////////////////////////////////////////////////////

void
on_buttonMP_GTA_clicked                (GtkButton       *button,
                                        gpointer         user_data)
{

}


void
on_buttonDec_GTA_clicked               (GtkButton       *button,
                                        gpointer         user_data)
{

}


void
on_buttonMP_AS_clicked                 (GtkButton       *button,
                                        gpointer         user_data)
{

}


void
on_buttonDec_AS_clicked                (GtkButton       *button,
                                        gpointer         user_data)
{

}


void
on_buttonMP_GT1_clicked                (GtkButton       *button,
                                        gpointer         user_data)
{

}


void
on_buttonDec_GT1_clicked               (GtkButton       *button,
                                        gpointer         user_data)
{

}


void
on_buttonMP_GT2_clicked                (GtkButton       *button,
                                        gpointer         user_data)
{

}


void
on_buttonDec_GT2_clicked               (GtkButton       *button,
                                        gpointer         user_data)
{

}


void
on_buttonMP_GT3_clicked                (GtkButton       *button,
                                        gpointer         user_data)
{

}


void
on_buttonDec_GT3_clicked               (GtkButton       *button,
                                        gpointer         user_data)
{

}


