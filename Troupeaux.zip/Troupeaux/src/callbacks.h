

#include <gtk/gtk.h>


void
on_buttonCalculer_GTA_clicked          (GtkWidget       *objet,
                                        gpointer         user_data);


void
on_buttonCalculer_AS_clicked           (GtkWidget       *objet,
                                        gpointer         user_data);


void
on_treeviewGT1_row_activated           (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data);


void
on_buttonAjouter_GT1_clicked           (GtkWidget       *objet,
                                        gpointer         user_data);


void
on_buttonModifier_GT1_clicked          (GtkWidget       *objet,
                                        gpointer         user_data);


void
on_buttonSupp_GT1_clicked              (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_buttonMAJ_clicked                   (GtkWidget       *objet,
                                        gpointer         user_data);


void
on_buttonConfirmer_GT2_clicked         (GtkWidget       *objet,
                                        gpointer         user_data);


void
on_buttonAfficher_GT2_clicked          (GtkWidget       *objet,
                                        gpointer         user_data);


void
on_radiobuttonM_GT2_toggled            (GtkToggleButton *togglebutton,
                                        gpointer         user_data);


void
on_radiobuttonF_GT2_toggled            (GtkToggleButton *togglebutton,
                                        gpointer         user_data);


void
on_checkbuttonVac_GT2_toggled          (GtkToggleButton *togglebutton,
                                        gpointer         user_data);


void
on_checkbuttonMal_GT2_toggled          (GtkToggleButton *togglebutton,
                                        gpointer         user_data);


void
on_checkbuttonGes_GT2_toggled          (GtkToggleButton *togglebutton,
                                        gpointer         user_data);


void
on_buttonRech_GT3_clicked              (GtkWidget       *objet,
                                        gpointer         user_data);


void
on_buttonConfirmer_GT3_clicked         (GtkWidget       *objet,
                                        gpointer         user_data);


void
on_buttonAfficher_GT3_clicked          (GtkWidget       *objet,
                                        gpointer         user_data);


void
on_radiobuttonM_GT3_toggled            (GtkToggleButton *togglebutton,
                                        gpointer         user_data);


void
on_radiobuttonF_GT3_toggled            (GtkToggleButton *togglebutton,
                                        gpointer         user_data);


void
on_checkbuttonVac_GT3_toggled          (GtkToggleButton *togglebutton,
                                        gpointer         user_data);


void
on_checkbuttonMal_GT3_toggled          (GtkToggleButton *togglebutton,
                                        gpointer         user_data);


void
on_checkbuttonGes_GT3_toggled          (GtkToggleButton *togglebutton,
                                        gpointer         user_data);


/////////////////////////////////////////////////////////////////////////////

void
on_buttonMP_GTA_clicked                (GtkButton       *button,
                                        gpointer         user_data);


void
on_buttonDec_GTA_clicked               (GtkButton       *button,
                                        gpointer         user_data);


void
on_buttonMP_AS_clicked                 (GtkButton       *button,
                                        gpointer         user_data);


void
on_buttonDec_AS_clicked                (GtkButton       *button,
                                        gpointer         user_data);


void
on_buttonMP_GT1_clicked                (GtkButton       *button,
                                        gpointer         user_data);


void
on_buttonDec_GT1_clicked               (GtkButton       *button,
                                        gpointer         user_data);


void
on_buttonMP_GT2_clicked                (GtkButton       *button,
                                        gpointer         user_data);


void
on_buttonDec_GT2_clicked               (GtkButton       *button,
                                        gpointer         user_data);


void
on_buttonMP_GT3_clicked                (GtkButton       *button,
                                        gpointer         user_data);


void
on_buttonDec_GT3_clicked               (GtkButton       *button,
                                        gpointer         user_data);


