#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "reservation.h"
#include "callbacks.h"
#include <sys/types.h>
#include <sys/stat.h>
#include <unistd.h>
#include <gdk/gdkkeysyms.h>
#include "LISTEVIEWAPPAREIL.h"

//remplir le tableau reservationAtelier à partir d'un fichier.txt

int tab_atelier_rsrv(reservationAtelier tab[])
{
int n=0;
FILE *f=fopen("atelierreserve.txt","r");
if(f!=NULL)
{
while(fscanf(f,"%s %d %d %d %d \n",tab[n].num,&tab[n].date_rsrv.Jour,&tab[n].date_rsrv.Mois,&tab[n].date_rsrv.Annee,&tab[n].heure_rsrv)!=EOF)
{ n++;}
fclose(f);
}
return n;
}

//Verfier si l'atelier est reservé ou pas
int verifier_rsrv(reservationAtelier a)
{
reservationAtelier ra;
int v=0;
FILE* f=fopen("atelierreserve.txt","r");
if (f!=NULL)
{
while(!v && fscanf(f,"%s %d %d %d %d" ,a.num ,&a.date_rsrv.Jour,&a.date_rsrv.Mois,&a.date_rsrv.Annee,&a.heure_rsrv)!=EOF)
{ if (strcmp(a.num,ra.num)==0)
	{if ((a.date_rsrv.Jour==ra.date_rsrv.Jour)&&(a.date_rsrv.Mois==ra.date_rsrv.Mois)&&(a.date_rsrv.Annee==ra.date_rsrv.Annee)&&(a.heure_rsrv==ra.heure_rsrv))
           {v++;}
        }
}
fclose(f);
//Liste des ateliers dispos
int tab_atelier_dispo(char NomAtelier[100], Date date_rsrv, int heure_rsrv)
{
int i,nA=0;
FILE *f;
f=fopen("atelier.txt","r");
reservationAtelier a;
a.date_rsrv = date_rsrv;
a.heure_rsrv =heure_rsrv;
if(f!=NULL)
{
	while(fscanf(f,"%s",a.num)!=EOF)
	{
	  if( a.num==NomAtelier)
            {
		int v =verifier_rsrv(a);
	      if(!v)
		{
		  strcpy(NomAtelier,a.num);
		  nA++;
		}
	}
}
}
fclose(f);

return (nA);
}
//reserver et enregistrer dans un fichier Atelier.txt
void reserver_atelier(reservationAtelier a)
{
FILE* f;
f=fopen("atelierreserve.txt","a");
	if(f!=NULL)
	{
	fprintf(f,"%s %d %d %d %d \n",a.num,a.date_rsrv.Jour,a.date_rsrv.Mois,a.date_rsrv.Annee,a.heure_rsrv);
	fclose(f);
	}
}
}
}

