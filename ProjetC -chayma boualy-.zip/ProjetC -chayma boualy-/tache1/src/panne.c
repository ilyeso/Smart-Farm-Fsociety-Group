#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "panne.h"
#include "callbacks.h"
#include <sys/types.h>
#include <sys/stat.h>
#include <unistd.h>
#include <gdk/gdkkeysyms.h>

void Resultat(int choix[], char texte[])
{
	strcpy(texte,"Le type de votre panne est:");
	if(choix[0]==1)
	strcat(texte," Panne externe");
	if(choix[1]==1)
	strcat(texte," Panne interne");
}
