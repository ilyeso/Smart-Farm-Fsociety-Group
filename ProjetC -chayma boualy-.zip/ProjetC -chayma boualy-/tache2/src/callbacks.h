#include <gtk/gtk.h>


void
on_buttonAFFICHERLOUVDELANNEE_clicked  (GtkWidget       *button,
                                        gpointer         user_data);

void
on_treeviewbestouv_row_activated       (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data);

void
on_buttonactualiser_clicked            (GtkWidget       *button,
                                        gpointer         user_data);
