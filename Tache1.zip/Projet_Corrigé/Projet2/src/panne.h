void Resultat(int choix[],char texte[]);
